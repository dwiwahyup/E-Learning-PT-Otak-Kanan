
<?php $__env->startSection('content'); ?>

<div id="login">
    <aside>
        <figure>
            <a href="index.html"><img src="<?php echo e(url('assets/dashboard/img/otakkanan.png')); ?>" width="155" height="36" data-retina="true" alt="" class="logo_sticky"></a>
        </figure>
        <?php if($errors->any()): ?>
            <div class="mb-4">
                <div class="font-medium text-red-600">
                    <?php echo e(__('Whoops! Something went wrong.')); ?>

                </div>

                <ul class="mt-3 list-disc list-inside text-sm text-red-600">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>

            <!-- Name -->
            <div class="form-group">
                <label for="name">
                    <?php echo e(__('Name')); ?>

                </label>

                <input id="name" name="name" value="<?php echo e(old('name')); ?>" required autofocus class="form-control" type="text">
                <i class="ti-user"></i>
            </div>

            <!-- Email Address -->
            <div class="form-group">
                <label for="email">
                    <?php echo e(__('Email')); ?>

                </label>

                <input class="form-control" name="email" type="email" id="email" value="<?php echo e(old('Email')); ?>" required>
                <i class="icon_mail_alt"></i>
            </div>

            <!-- Password -->
            <div class="form-group">
                <label for="password">
                    <?php echo e(__('Password')); ?>

                </label>

                <input class="form-control" name="password" type="password" id="password" required autocomplete="new-password">
                <i class="icon_lock_alt"></i>
            </div>

            <!-- Confirm Password -->
            <div class="form-group">
                <label for="password_confirmation">
                    <?php echo e(__('Confirm Password')); ?>

                </label>

                <input name="password_confirmation" class="form-control" type="password" id="password_confirmation" required>
                <i class="icon_lock_alt"></i>
            </div>

            <div class="flex items-center justify-end mt-4">
                

                <button type="submit" class="btn_1 rounded full-width add_top_30">
                    <?php echo e(__('Register')); ?>

                </button>
            </div>

            <div id="pass-info" class="clearfix"></div>

            <div class="text-center add_top_10">Already have an acccount? <strong><a href="<?php echo e(route('login')); ?>">Sign In</a></strong></div>
        </form>
        <div class="copy">© 2018 Panagea</div>
    </aside>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('login_register.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/auth/register.blade.php ENDPATH**/ ?>