
<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="/dashboard">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('logbooks.index')); ?>">Logbooks Course</a>
            </li>
            <li class="breadcrumb-item active">Logbooks <?php echo e($course->name); ?> Student</li>
        </ol>
        <?php if($message = Session::get('success')): ?>
        <div class="mb-10">
            <div class="alert alert-success" role="alert">
                <p><?php echo e($message); ?></p>
            </div>
        </div>
        <?php endif; ?>
        <!-- Example DataTables Card-->
        <div class="card mb-3">
            <div class="card-header">
                <i class="fa fa-table"></i> Student logbook <?php echo e($course->name); ?>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Total Logbooks</th>
                                <th>Logbooks waiting</th>
                                <th>Logbooks approved</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Total logbooks</th>
                                <th>Logbooks waiting</th>
                                <th>Logbooks approved</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td>create <?php echo e($item->logbooks->count()); ?> logbooks</td>
                                        <td><?php echo e($item->logbooks->where('status', 0)->count()); ?> Waiting to approved</td>
                                        <td><?php echo e($item->logbooks->where('status', 1)->count()); ?> approved</td>
                                <td>
                                    <div class="d-flex">
                                        <a href="/dashboard/logbook/students/show/<?php echo e($item->slug); ?>" class="btn btn-success btn-md">Detail logbooks</a>
                                    </div>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
        </div>
        <!-- /tables-->
    </div>
    <!-- /container-fluid-->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/dashboard/logbook/students-logbooks.blade.php ENDPATH**/ ?>