
<?php $__env->startSection('content'); ?>

<main>
    <section class="hero_in general">
        <div class="wrapper">
            <div class="container">
                <h1 class="fadeInUp"><span></span><?php echo e($course->name); ?></h1>
            </div>
        </div>
    </section>
    <!--/hero_in-->

    <div class="bg_color_1">
        <nav class="secondary_nav sticky_horizontal">
            <div class="container">
                <ul class="clearfix">
                    <li><a href="#description" class="active">Description</a></li>
                    
                    <li><a href="#sidebar">Contact</a></li>
                </ul>
            </div>
        </nav>
        <div class="container margin_60_35">
            <div class="row">
                <div class="col-lg-8">
                    <section id="description">
                        <h2>Description</h2>
                        
                        <?php if($data->vidio == null): ?>
                        <?php else: ?>
                            <iframe style="height: 405px; overflow-x:auto; "
                                src="<?php echo e($data->vidio); ?>">
                            </iframe>   
                        <?php endif; ?>
                            
                        <?php if($data->thumbnaile_url == null): ?>
                            
                        <?php else: ?>
                            <p><img alt="" class="img-fluid"  style="width: 800px; height: 400px;" src="<?php echo e($data->thumbnaile_url); ?>"></p>
                        <?php endif; ?>
                        <!-- /post meta -->
                        <div class="post-content">
                            <p><?php echo $data->text; ?></p>
                        </div>

                    </section>
                    <!-- /section -->
                    <hr>
                </div>
                <!-- /col -->
                
                <aside class="col-lg-4" id="sidebar">
                    <div class="box_detail booking">
                        <div>
                            <?php if($next == null): ?>
                                <?php if($next_chapter == null): ?>
                                    <a href="/chapteruser/<?php echo e($course->slug); ?>">
                                        <h5 class="d-inline">Akhir materi</h5>
                                        <br>    
                                        <p><?php echo e($end_content->title); ?>

                                            
                                        </p>
                                    </a>
                                <?php else: ?>
                                <a href="/contentuser/<?php echo e($next_chapter->slug ?? $end_content->name); ?>">
                                    <h5 class="d-inline">Selanjutnya</h5>
                                    <br>    
                                    <p><?php echo e($next_chapter->title ?? $end_content->title); ?>

                                        <i class="icon-left"></i> 
                                    </p>
                                </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="/contentuser/<?php echo e($next->slug); ?>">
                                    <h5 class="d-inline">Selanjutnya</h5>
                                    <br>    
                                    <p><?php echo e($next->title); ?><i class=" icon-left"></i> </p>
                                </a>
                            <?php endif; ?>

                        </div>
                        
                    
                </aside>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!-- /bg_color_1 -->
</main>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('frontend/layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/frontend/contentuser/index.blade.php ENDPATH**/ ?>