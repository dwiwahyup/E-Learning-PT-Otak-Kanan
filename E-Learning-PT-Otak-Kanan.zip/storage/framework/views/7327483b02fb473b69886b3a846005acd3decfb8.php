

<?php $__env->startSection('content'); ?>
<main>
    <section class="hero_single version_2">
        <div class="wrapper">
            <div class="container">
                <h3>Start Your Carrer</h3>
                <p>Expolore Your Interest and Upgrade Your Skills </p>
                <br>
                <p class="btn_home">
                    <a href="/program/" class="btn_1 rounded">Join Now</a>
                </p>
            </div>
        </div>
    </section>

    <div class="container container-custom margin_80_0">
        <div class="main_title_2">
            <span><em></em></span>
            <h2>Our Course</h2>
            <p>Cum doctus civibus efficiantur in imperdiet deterruisset.</p>
        </div>
        <div id="reccomended" class="owl-carousel owl-theme">
            <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <div class="box_grid">
                    <figure>
                        <a href="/chapteruser/<?php echo e($item->slug); ?>"><img src="<?php echo e($item->image_url); ?>" class="img-fluid"
                                alt="" width="800" height="533">
                            <div class="read_more"><span>Read more</span></div>
                        </a>
                        <small><?php echo e($item->name); ?></small>
                    </figure>
                    <div class="wrapper">
                        <h3><a href="/chapteruser/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a></h3>
                        <p><?php echo Str::limit($item->introduction, 150); ?></p>
                        <span class="price"> <strong><?php echo e($item->chapters_count); ?></strong> Chapters and
                            <strong><?php echo e($item->mentors_count); ?> </strong>
                            Profesional
                            Mentors</span>
                    </div>
                    <ul>
                        <li></li>
                        <li>
                            <div class="score"><a href=""><strong>Start Now</strong></a></div>
                        </li>
                    </ul>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <p class="btn_home_align"><a href="<?php echo e(url('/allcourse/')); ?>" class="btn_1 rounded">View all Courses</a></p>
        <hr class="large">
    </div>

    <div class="bg_color_1">
        <div class="container container-custom margin_80_55">
            <div class="main_title_2">
                <h2>Why do you have to follow<br>
                    internship program at PT. Otak Kanan?</h2>
            </div>
            <div class="row adventure_feat">
                <div class="col-md-3">
                    <img src="frontend/img/paste-solid.svg" alt="" width="75" height="75"><br>
                    <p>Practical activities can be converted into credits</p>
                </div>
                <div class="col-md-3">
                    <img src="frontend/img/knowladge.png" alt="" width="75" height="75"><br>
                    <p>Ease of exploration of students' knowledge and abilities during the activity</p>
                </div>
                <div class="col-md-3">
                    <img src="frontend/img/networking.png" alt="" width="75" height="75"><br>
                    <p>Learn and expand networks outside of the home campus</p>
                </div>
                <div class="col-md-3">
                    <img src="frontend/img/teacher.png" alt="" width="75" height="75"><br>
                    <p>Gain knowledge and experience from professional and qualified partners.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container margin_95_40">
        <div class="main_title_2">
            <span><em></em></span>
            <h2>Our Mentors</h2>
            <p>Cum doctus civibus efficiantur in imperdiet deterruisset.</p>
        </div>
        <div id="carousel" class="owl-carousel owl-theme">
            <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <a href="#0">
                    <div class="title">
                        <h4><?php echo e($data->name); ?>

                            <em><?php echo e($data->courses->name ?? "Coming soon"); ?></em>
                            <hr>
                        </h4>
                    </div>
                    <img src="<?php echo e($data->user_details->profile_photo ?? "https://res.cloudinary.com/djbbzawzs/image/upload/v1667293146/picture_assets_frontend/mentor2_dg1wij.jpg"); ?>"
                        alt="">
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="bg_color_1">
        <div class="container margin_80_55">
            <div class="main_title_2">
                <span><em></em></span>
                <h2>Testimonials</h2>
            </div>
            <div class="row">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6">
                    <a class="box_news" href="#0">
                        <figure><img src="<?php echo e($item->users->courses->image_url ?? url('frontend/img/news_home_1.jpg')); ?>"
                                alt="">
                        </figure>
                        <div class="info">
                            <?php echo e($item->created_at->toFormattedDateString()); ?>

                            <ul>
                                <li>
                                    <strong><?php echo e($item->name); ?></strong>
                                </li>
                            </ul>
                            <div class="cat_star">
                                <?php for($i = 0; $i < $item->rating; $i++): ?>
                                    <i class="icon_star"></i>
                                    <?php endfor; ?>
                            </div>
                        </div>
                        <p align="justify"><?php echo e(Str::limit($item->review, 130)); ?></p>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <p class="btn_home_align"><a href="<?php echo e(route('user_testimonial.index')); ?>" class="btn_1 rounded">View all
                    Testimonials</a>
            </p>
        </div>
    </div>
</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend/layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/frontend/home.blade.php ENDPATH**/ ?>