

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(('/dashboard')); ?>">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(('/dashboard/coursecategory')); ?>">Course</a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('coursecategory.chapter.index', $coursecategory->slug)); ?>"> <?php echo e($chapters->name); ?></a>
            </li>
            <li class="breadcrumb-item active">Content</li>
        </ol>
        
        <?php if($message = Session::get('success')): ?>
                    <div class="mb-10">
                        <div class="alert alert-success" role="alert">
                            <p><?php echo e($message); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
        <!-- Example DataTables Card-->
        <div class="card mb-3">
            <div class="card-header">
                <i class="fa fa-table"></i> Content Data
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <p><a href="<?php echo e(route('coursecategory.chapter.content.create', ['coursecategory' => $coursecategory->slug, 'chapter' => $chapters->slug])); ?>" class="btn btn-secondary plus"> Add Content</a></p>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Text</th>
                                <th>Thumbnile</th>
                                <th>Created</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Name</th>
                                <th>Text</th>
                                <th>Thumbnile</th>
                                <th>Created</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->title); ?></td>
                                <td><?php echo Str::words($data->text, 50); ?></td>
                                
                                <td>    
                                        <?php if($data->thumbnaile_url != null): ?>
                                            <img src="<?php echo e($data->thumbnaile_url); ?>" alt="" width="200px" height="100px">
                                        <?php else: ?>
                                        <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($data->created_at); ?>

                                </td>
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('coursecategory.chapter.content.edit', ['coursecategory' => $coursecategory->slug, 'chapter' => $chapters->slug, 'content' => $data->slug])); ?>" class="btn btn-success btn-md">Edit</a>
                                        
                                        <form action="<?php echo e(route('coursecategory.chapter.content.destroy', ['coursecategory' => $coursecategory->id, 'chapter' => $chapters->id, 'content' => $data->id])); ?>" class="d-inline" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('delete')); ?>

                                            <button class="btn btn-danger ml-2">Delete</button>
                                        </form>
                                        <a href="/dashboard/content/preview/<?php echo e($data->slug); ?>" class="btn btn-danger btn-md ml-2" >Preview</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
        </div>
        <!-- /tables-->
    </div>
    <!-- /container-fluid-->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/dashboard/content/index.blade.php ENDPATH**/ ?>