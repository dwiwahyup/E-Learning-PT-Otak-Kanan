

<?php $__env->startSection('content'); ?>



<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(('/dashboard')); ?>">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(('/dashboard/coursecategory')); ?>">Course</a>
            </li>
            <li class="breadcrumb-item active">Chapter</li>
        </ol>
        
        <?php if($message = Session::get('success')): ?>
        <div class="mb-10">
            <div class="alert alert-success" role="alert">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <p>
                <a href="<?php echo e(route('coursecategory.chapter.create', $course_name->slug)); ?>" class="btn btn-secondary plus">
                    Add Chapter</a>
            </p>
            

            <div class="col-lg-12" id="faq">
                <h5 class="nomargin_top">Course Name : <?php echo e($course_name->name); ?></h5>
                <div role="tablist" class="add_bottom_45 accordion_2" id="payment">
                    <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card">
                        <div class="card-header" role="tab">
                            <h5 class="mb-0">
                                <a data-toggle="collapse" href="#<?php echo e($data->id); ?>" aria-expanded="true"><i
                                        class="indicator "><small><strong>Total Content : <?php echo e($data->contents_count); ?></strong></small></i>
                                    <?php echo e($index+1); ?>. <?php echo e($data->name); ?>

                                </a>
                            </h5>
                        </div>
                        <div id="<?php echo e($data->id); ?>" class="collapse " role="tabpanel" data-parent="#payment">
                            <div class="card-body">
                                <p>
                                    <?php echo e($data->abstract); ?>

                                </p>
                                <div class="mt-3 font-weight-normal" role="group"
                                    aria-label="Basic mixed styles example">
                                    <a class="mr-2"
                                        href="<?php echo e(route('coursecategory.chapter.edit', ['coursecategory' => $course_name->slug, 'chapter' => $data->slug])); ?>">
                                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>
                                    <a class="mr-2"
                                        href="<?php echo e(route('coursecategory.chapter.content.index', ['coursecategory' => $course_name->slug, 'chapter' => $data->slug])); ?>">
                                        <i class="fa fa-list-alt" aria-hidden="true"></i> Content List</a>
                                    <a class="mr-2" href="/dashboard/quiz/<?php echo e($data->id); ?>">
                                        <i class="fa fa-question-circle" aria-hidden="true"></i> Quiz</a>
                                    <a href="" type="button" data-toggle="modal" data-target="#exampleModal">
                                        <i class="fa fa-trash" aria-hidden="true"></i> Delete</a>
                                </div>
                                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Delete chapter</h5>
                                                <button class="close" type="button" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true"></span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                Are you sure to delete this chapter ?
                                            </div>
                                            <div class="modal-footer">
                                                <button class="btn btn-secondary" type="button"
                                                    data-dismiss="modal">Cancel</button>
                                                <form
                                                    action="<?php echo e(route('coursecategory.chapter.destroy', ['coursecategory' => $course_name->id, 'chapter' => $data->id])); ?>"
                                                    class="d-inline" method="POST">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('delete')); ?>

                                                    <button class="btn btn-danger">Delete</button>
                                                </form>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- BASE CSS -->

<link href="<?php echo e(url('frontend/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('frontend/css/vendors.css')); ?>" rel="stylesheet">

<!-- YOUR CUSTOM CSS -->

<script src="<?php echo e(url('frontend/js/common_scripts.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/main.js')); ?>"></script>
<script src="<?php echo e(url('frontend/assets/validate.js')); ?>"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/dashboard/chapter/index.blade.php ENDPATH**/ ?>