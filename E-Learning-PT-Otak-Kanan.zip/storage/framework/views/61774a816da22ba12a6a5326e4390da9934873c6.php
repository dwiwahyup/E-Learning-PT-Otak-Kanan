
<?php $__env->startSection('content'); ?>


<div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">My Profile</li>
    </ol>
		<div class="box_general padding_bottom">
			<div class="header_box version_2">
				<h2><i class="fa fa-user"></i>Profile Details</h2>
			</div>
			<div class="row">
                <div class="col-lg-4 add_top_30">
                    <div class="card">
                        <div class="card-body profile-card">
                            <center class="mt-6"> <img src="<?php echo e($users->user_details->profile_photo ?? "https://res.cloudinary.com/djbbzawzs/image/upload/v1669355293/picture_assets_frontend/avatar_twx4zp.jpg"); ?>" class="rounded-circle" width="175">
                            </center>
                        </div>
                    </div>
					 
                </div>
				<div class="col-md-8 add_top_35">
					<div class="row">
						<div class="col-md-8">
							<div class="form-group">
								<label>Name</label>
								<input type="text" value="<?php echo e($users->name); ?>" disabled class="form-control">
							</div>
						</div>
					</div>
                    <div class="row">
						<div class="col-md-8">
							<div class="form-group">
								<label>Email</label>
								<input type="text" class="form-control" disabled value="<?php echo e($users->email); ?>">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-8">
							<div class="form-group">
								<label>Phone Number</label>
								<input type="text" class="form-control" disabled value="<?php echo e($users->user_details->phone_numbers ?? ""); ?>">
							</div>
						</div>
					</div>
					<?php if($users->courses()->exists()): ?>
						<div class="row">
							<div class="col-md-8">
								<div class="form-group">
									<label>Course</label>
									<input type="text" class="form-control" disabled value="<?php echo e($users->courses->name); ?>">
								</div>
							</div>
						</div>
					<?php endif; ?>
						<div class="row">
							<div class="col-md-8">
								<div class="form-group">
									<label>Alamat</label>
									<input type="text" class="form-control" disabled value="<?php echo e($users->user_details->address ?? ""); ?>">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-8">
								<div class="form-group">
									<label>Jenis Kelamin</label>
									<input type="text" class="form-control" disabled 
									value="<?php if($users->user_details()->exists()): ?><?php if($users->user_details->gender === 0): ?>laki-laki <?php else: ?> perempuan
									<?php endif; ?>

									<?php endif; ?>">
										
								</div>
							</div>
						</div>
				</div>
			</div>
		</div>
		
		<div class="inline-block">
			<p>
				<?php if($users->user_details()->exists()): ?>
				<a href="<?php echo e(route('profile.edit', $users->slug)); ?>" class="btn_1 medium d-inline"> Edit</a>
				<?php else: ?>
				<a href="<?php echo e(route('profile.create')); ?>" class="btn_1 medium d-inline">Complete profile</a>
				<?php endif; ?>
			</p>
			<p></p>
		</div>
    </div>
    <!-- /.container-fluid-->
		
	
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/dashboard/profile/index.blade.php ENDPATH**/ ?>