<header class="header menu_fixed">
    <div id="preloader">
        <div data-loader="circle-side"></div>
    </div><!-- /Page Preload -->
    <div id="logo">
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(url('assets/dashboard/img/otakkanan.png')); ?>" width="150" height="36" alt=""
                class="logo_normal">
        </a>
    </div>
    <a href="#menu" class="btn_mobile">
        <div class="hamburger hamburger--spin" id="hamburger">
            <div class="hamburger-box">
                <div class="hamburger-inner"></div>
            </div>
        </div>
    </a>
    <nav id="menu" class="main-menu">
        <ul>
            <li><span><a href="<?php echo e(url('/')); ?>">Home</a></span></li>
            <li><span><a href="<?php echo e(url('/program/')); ?>">Program</a></span></li>
            <li><span><a href="<?php echo e(url('/allcourse/')); ?>">Course</a></span></li>
            <li><span><a href="<?php echo e(url('/about')); ?>">About</a></span></li>
            <?php if(auth()->guard()->guest()): ?>
            <li><span><a href="<?php echo e(route('login')); ?>">Login</a></span>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
            <li><span><a href="#0">Account</a></span>
                <ul>
                        <?php if(Auth::user()->roles == "USER"): ?>
                            <li><a href="<?php echo e(route('MyProfile.index')); ?>">Profile</a></li>
                            <li><a href="<?php echo e(route('my_logbooks.index')); ?>">LogBook</a></li>
                        <?php endif; ?>
                        <li>
                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"> Logout</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        </ul>
    </nav>
</header>
<?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/frontend/layouts/navbar.blade.php ENDPATH**/ ?>