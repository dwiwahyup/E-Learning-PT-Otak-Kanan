

<?php $__env->startSection('content'); ?>


<div class="content-wrapper">
    <div class="container-fluid">

        <a class="btn btn-link mb-2" href="<?php echo e(URL::previous()); ?>">
            <i class="fa fa-chevron-left" aria-hidden="true"></i> Back
        </a>

        <?php if($errors->any()): ?>
        <div class="mb-5" role="alert">
            <div class="alert alert-danger" role="alert">
                <p>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eror): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($eror); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </p>
            </div>
        </div>
        <?php endif; ?>

        <div class="box_general padding_bottom">
            <div class="header_box version_2">
                <h2><i class="fa fa-file"></i>Edit Chapter</h2>
            </div>

            
            <form
                action="<?php echo e(route('coursecategory.chapter.update', ['coursecategory' => $coursecategory->id, 'chapter' => $chapter->id])); ?>"
                method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label>Chapter Name</label>
                            <input type="text" name="name" value="<?php echo e($chapter->name); ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Abstract</label>
                            <textarea type="text" class="form-control" name="abstract"><?php echo e($chapter->abstract); ?></textarea>
                        </div>
                    </div>
                </div>
                <!-- /row-->
                <!-- /row-->
                <p><button type="submit" class="btn btn-primary plus float-right">Save</button></p>
            </form>
        </div>
    </div>
    <!-- /.container-fluid-->
</div>
<!-- /.container-wrapper-->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fa fa-angle-up"></i>
</a>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/dashboard/chapter/edit.blade.php ENDPATH**/ ?>