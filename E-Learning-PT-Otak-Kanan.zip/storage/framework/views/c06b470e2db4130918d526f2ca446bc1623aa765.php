

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(('/dashboard')); ?>">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(('/dashboard/program')); ?>">Program</a>
            </li>
            <li class="breadcrumb-item active">Kompetensi</li>
        </ol>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success" role="alert">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <!-- Example DataTables Card-->
        <div class="card mb-3">
            <div class="card-header">
                <i class="fa fa-table"></i> Kriteria
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <p><a href="<?php echo e(route('program.kompetensi.create', $nama_program->slug)); ?>"
                            class="btn btn-secondary plus"> Add Kompetensi</a></p>
                    <div class="header_box">
                        <h2 class="d-inline-block">Program : <?php echo e($nama_program->nama); ?></h2>
                    </div>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Kriteria Yang Dikembangkan</th>
                                <th>Target Pengembangan Keterampilan</th>
                                <th>Detail Pembelajaran</th>
                                <th>Metode Asesmen</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Kriteria Yang Dikembangkan</th>
                                <th>Target Pengembangan Keterampilan</th>
                                <th>Detail Pembelajaran</th>
                                <th>Metode Asesmen</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->nama_kompetensi); ?></td>
                                <td><?php echo e($data->target_pengembangan_keterampilan); ?></td>
                                <td><?php echo e($data->detail_pembelajaran); ?></td>
                                <td><?php echo e($data->metode_asesment); ?></td>
                                <td>
                                    <div class="">
                                        <a href="<?php echo e(route('program.kompetensi.edit', ['program' => $data->programs->slug, 'kompetensi' => $data->slug])); ?>"
                                            class="btn btn-success btn-md">Edit</a>
                                        <form
                                            action="<?php echo e(route('program.kompetensi.destroy', ['program' => $data->programs->id, 'kompetensi' => $data->id])); ?>"
                                            class="d-inline" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('delete')); ?>

                                            <button class="btn btn-danger">Delete</button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
        </div>
        <!-- /tables-->
    </div>
    <!-- /container-fluid-->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/dashboard/kompetensi/index.blade.php ENDPATH**/ ?>