

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container-fluid">
        <a class="btn btn-link mb-2" href="">
            <i class="fa fa-chevron-left" aria-hidden="true"></i> Back
        </a>

        <?php if($errors->any()): ?>
        <div class="mb-5" role="alert">
            <div class="alert alert-danger" role="alert">
                <p>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eror): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($eror); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Example DataTables Card-->
        <div class="card mb-3">
            <div class="card-header">
                <i></i> Tambah Materi Baru
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('program.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group">

                                        <label for="inputState">Nama Program</label>
                                        <select id="inputState" class="form-control" name="nama">
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($course->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Jumlah SKS</label>
                                        <input type="text" name="jumlah_sks" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Tanggal Mulai</label>
                                        <input class="form-control" type="date" name="tanggal_mulai">
                                        <i class="icon_calendar"></i>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Tanggal Selesai</label>
                                        <input class="form-control" type="date" name="tanggal_selesai">
                                        <i class="icon_calendar"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Metode Kegiatan</label>
                                        <input class="form-control" type="name" name="metode_kegiatan">
                                        <i class="icon_calendar"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>Kegiatan</label>
                                        <input class="form-control" type="name" name="kegiatan">
                                        <i class="icon_calendar"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Rincian Kegiatan</label>
                                <textarea class="editor" name="rincian_kegiatan"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Kriteria Peserta</label>
                                <textarea class="editor" name="kriteria_peserta"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Informasi Kegiatan</label>
                                <textarea class="editor" name="informasi_tambahan"></textarea>
                            </div>
                        </div>
                    </div>
                    <p><button type="submit" class="btn btn-primary plus float-right">Save</button></p>
                </form>
            </div>
            <!-- /tables-->
        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/dashboard/program/create.blade.php ENDPATH**/ ?>