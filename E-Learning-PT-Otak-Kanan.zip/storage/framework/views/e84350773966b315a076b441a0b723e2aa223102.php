
<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="/dashboard">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('logbooks.index')); ?>">Logbooks Course</a>
            </li>
            <li class="breadcrumb-item">
                <a href="/dashboard/logbook/students/<?php echo e($user->courses->slug); ?>">Logbooks Student <?php echo e($user->courses->name); ?></a>
            </li>
            <li class="breadcrumb-item active"><?php echo e($user->name); ?></li>
        </ol>
        <?php if($message = Session::get('success')): ?>
        <div class="mb-10">
            <div class="alert alert-success" role="alert">
                <p><?php echo e($message); ?></p>
            </div>
        </div>
        <?php endif; ?>
        <!-- Example DataTables Card-->
        <div class="card mb-3">
            <div class="card-header">
                <i class="fa fa-table"></i> Logbook Data <?php echo e($user->name); ?>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Description</th>
                                <th>Submited on</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Description</th>
                                <th>Submited on</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->description); ?></td>
                                <td><?php echo e($item->date); ?></td>
                                <td>
                                    <?php if($item->status == 0): ?>
                                        Waiting
                                    <?php else: ?>
                                        Aproved
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex">
                                        
                                        <a href="" type="button" class="btn btn-primary btn-md" data-toggle="modal" data-target="#exampleModal">Edit</a>
                                    </div>
                            </tr>
                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Delete chapter</h5>
                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true"></span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('logbooks.update', $item->id)); ?>"  method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="row">
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <label>Status</label>
                                                            <div class="styled-select">
                                                                <select name="status">
                                                                    <option value="<?php echo e($item->status); ?>">
                                                                    <?php if($item->status == 0): ?>
                                                                        Waiting
                                                                    <?php else: ?>
                                                                        Approved
                                                                    <?php endif; ?>
                                                                    </option>
                                                                        <option value="1">Approved</option>
                                                                        <option value="0">Waiting</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- /row-->
                                            <p><button type="submit" class="btn btn-primary plus float-right">Update</button></p>
                                        </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                        </div>
                                    </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
        </div>
        <!-- /tables-->
    </div>
    <!-- /container-fluid-->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/dashboard/logbook/students-logbooks-show.blade.php ENDPATH**/ ?>