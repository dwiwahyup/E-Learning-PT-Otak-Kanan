

<?php $__env->startSection('content'); ?>

<div id="login" class="fixed-top">
    <div class="mb-4 font-medium text-sm text-green-600">
        <?php echo e(session('status')); ?>

    </div>

    <aside>
        <figure>
            <a href="index.html"><img src="<?php echo e(url('assets/dashboard/img/otakkanan.png')); ?>" width="155" height="36" data-retina="true" alt="" class="logo_sticky"></a>
        </figure>
        <?php if($errors->any()): ?>
        <div class="mb-4">
            <div class="font-medium text-red-600">
                <?php echo e(__('Whoops! Something went wrong.')); ?>

            </div>
        
            <ul class="mt-3 list-disc list-inside text-sm text-red-600">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            

            <div class="form-group">
                <label for="Email">
                    <?php echo e(__('Email')); ?>

                </label>
                <input  class="form-control" id="email" type="email" name="email" :value="old('email')" required autofocus>
                <i class="icon_mail_alt"></i>
            </div>
            <div class="form-group">
                <label for="password" class="block font-medium text-sm text-gray-700">
                    <?php echo e(__('Password')); ?>

                </label>
                <input class="form-control" id="password"  type="password" name="password" required autocomplete="current-password">
                <i class="icon_lock_alt"></i>
            </div>

            <div class="block mt-4">
                <label for="remember_me" class="inline-flex items-center">
                    <input id="remember_me" type="checkbox" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" name="remember">
                    <span class="ml-2 text-sm text-gray-600"><?php echo e(__('Remember me')); ?></span>
                </label>
            </div>

            <div class="flex items-center justify-end mt-4">
                <?php if(Route::has('password.request')): ?>
                    <a class="underline text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Forgot your password?')); ?>

                    </a>
                <?php endif; ?>

                <button type="submit" class="btn_1 rounded full-width">
                    <?php echo e(__('Log in')); ?>

                </button>
            </div>

            <div class="text-center add_top_10">Don't have an account? <strong><a href="<?php echo e(route('register')); ?>">Sign up!</a></strong></div>
        </form>
        <div class="copy">© 2018 Panagea</div>
    </aside>
</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('login_register/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/auth/login.blade.php ENDPATH**/ ?>