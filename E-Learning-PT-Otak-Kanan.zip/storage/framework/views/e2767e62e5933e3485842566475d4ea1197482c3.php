<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ansonika">
    <title>Dashboard</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="<?php echo e(url('assets/dashboard/img/favicon.ico')); ?>" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="<?php echo e(url('assets/dashboard/img/apple-touch-icon-57x57-precomposed.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="<?php echo e(url('assets/dashboard/img/apple-touch-icon-72x72-precomposed.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="<?php echo e(url('assets/dashboard/img/apple-touch-icon-114x114-precomposed.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="<?php echo e(url('assets/dashboard/img/apple-touch-icon-144x144-precomposed.png')); ?>">

    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800" rel="stylesheet">

    <!-- Bootstrap core CSS-->
    <link href="<?php echo e(url('assets/dashboard/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Main styles -->
    <link href="<?php echo e(url('assets/dashboard/css/admin.css')); ?>" rel="stylesheet">
    <!-- Icon fonts-->
    <link href="<?php echo e(url('assets/dashboard/vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- Plugin styles -->
    <link href="<?php echo e(url('assets/dashboard/vendor/datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/dashboard/vendor/dropzone.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/dashboard/css/date_picker.css')); ?>" rel="stylesheet">
    
    <!-- Your custom styles -->
    <link href="<?php echo e(url('assets/dashboard/css/custom.css')); ?>" rel="stylesheet">

    <!-- WYSIWYG Editor -->
    <link rel="stylesheet" href="<?php echo e(url('assets/dashboard/js/editor/summernote-bs4.css')); ?>">
</head>

<body class="fixed-nav sticky-footer" id="page-top">
    <!-- Navigation-->
    <?php echo $__env->make('components.dashboard.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /Navigation-->

    <!-- /.container-wrapper-->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- end -->

    <!-- footer -->
    <?php echo $__env->make('components.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end of footer -->
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(url('assets/dashboard/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(url('assets/dashboard/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo e(url('assets/dashboard/vendor/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/dashboard/vendor/chart.js/Chart.js')); ?>"></script>
    <script src="<?php echo e(url('assets/dashboard/vendor/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(url('assets/dashboard/vendor/datatables/dataTables.bootstrap4.js')); ?>"></script>
    <script src="<?php echo e(url('assets/dashboard/vendor/jquery.selectbox-0.2.js')); ?>"></script>
    <script src="<?php echo e(url('assets/dashboard/vendor/retina-replace.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/dashboard/vendor/jquery.magnific-popup.min.js')); ?>"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(url('assets/dashboard/js/admin.js')); ?>"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo e(url('assets/dashboard/js/admin-charts.js')); ?>"></script>
    <script src="<?php echo e(url('assets/dashboard/js/admin-datatables.js')); ?>"></script>

    <script src="<?php echo e(url('assets/dashboard/vendor/dropzone.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/dashboard/vendor/bootstrap-datepicker.js')); ?>"></script>
    <script>$('input.date-pick').datepicker();</script>
    <!-- WYSIWYG Editor -->
    <script src="<?php echo e(url('assets/dashboard/js/editor/summernote-bs4.min.js')); ?>"></script>
    <script>
    $('.editor').summernote({
    fontSizes: ['10', '14'],
    toolbar: [
    // [groupName, [list of button]]
    ['style', ['bold', 'italic', 'underline', 'clear']],
    ['font', ['strikethrough']],
    ['fontsize', ['fontsize']],
    ['insert', ['link', 'picture', 'video']],
    ['para', ['ul', 'ol', 'paragraph']]
    ],
        placeholder: 'Write here your description....',
        tabsize: 2,
        height: 500
    });
    </script>
</body>

</html><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>