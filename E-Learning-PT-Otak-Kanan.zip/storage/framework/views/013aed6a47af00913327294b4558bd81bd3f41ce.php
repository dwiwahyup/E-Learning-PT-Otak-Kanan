<footer class="sticky-footer">
    <div class="container">
        <div class="text-center">
            <small>Copyright © PANAGEA 2018</small>
        </div>
    </div>
</footer><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/components/dashboard/footer.blade.php ENDPATH**/ ?>