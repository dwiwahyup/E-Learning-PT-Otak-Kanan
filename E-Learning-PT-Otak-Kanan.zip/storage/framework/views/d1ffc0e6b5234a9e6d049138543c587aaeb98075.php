

<?php $__env->startSection('content'); ?>




<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">My Dashboard</li>
        </ol>
        <!-- Icon Cards-->
        <div class="row">
            <div class="col-xl-4 col-sm-6 mb-6">
                <div class="card dashboard text-white bg-info o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fa-user-circle" aria-hidden="true"></i>
                        </div>
                        <div class="mr-5">
                            <h5>Users <?php echo e($userr); ?></h5>
                        </div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="<?php echo e(url('dashboard/user')); ?>">
                        <span class="float-left">View Details</span>
                        <span class="float-right">
                            <i class="fa fa-angle-right"></i>
                        </span>
                    </a>
                </div>
            </div>
            <div class="col-xl-4 col-sm-6 mb-6">
                <div class="card dashboard text-white bg-info o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fa-address-card-o" aria-hidden="true"></i>
                        </div>
                        <div class="mr-5">
                            <h5>Courses <?php echo e($courses); ?></h5>
                        </div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="<?php echo e(url('dashboard/user')); ?>">
                        <span class="float-left">View Details</span>
                        <span class="float-right">
                            <i class="fa fa-angle-right"></i>
                        </span>
                    </a>
                </div>
            </div>
            <div class="col-xl-4 col-sm-6 mb-6">
                <div class="card dashboard text-white bg-info o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fas fa-users" aria-hidden="true"></i>
                        </div>
                        <div class="mr-5">
                             <h5>Mentors <?php echo e($mentors); ?></h5>
                        </div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="<?php echo e(url('dashboard/mentors')); ?>">
                        <span class="float-left">View Details</span>
                        <span class="float-right">
                            <i class="fa fa-angle-right"></i>
                        </span>
                    </a>
                </div>
            </div>
            
        </div>     

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/dashboard/index.blade.php ENDPATH**/ ?>