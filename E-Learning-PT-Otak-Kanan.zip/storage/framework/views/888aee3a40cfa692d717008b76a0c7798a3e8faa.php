

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container-fluid">
        <a class="btn btn-link mb-2" href="<?php echo e(URL::previous()); ?>">
            <i class="fa fa-chevron-left" aria-hidden="true"></i> Back
        </a>

        <!-- Example DataTables Card-->
        <div class="card mb-3">
            <div class="card-header">
                <i></i> Edit Progarm
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('program.update', $data->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group">

                                        <label for="inputState">Nama Program</label>
                                        <select id="inputState" class="form-control" name="nama">

                                            <option><?php echo e(old('nama') ?? $data->nama); ?></option>
                                            <?php $__currentLoopData = $dataa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($course->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            

                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Jumlah SKS</label>
                                        <input type="text" name="jumlah_sks" class="form-control" value="<?php echo e(old('jumlah_sks') ?? $data->jumlah_sks); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Tanggal Mulai</label>
                                        <input class="form-control" type="date" name="tanggal_mulai" value="<?php echo e(old('tanggal_mulai') ?? $data->tanggal_mulai); ?>">
                                        <i class="icon_calendar"></i>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Tanggal Selesai</label>
                                        <input class="form-control" type="date" name="tanggal_selesai" value="<?php echo e(old('tanggal_selesai') ?? $data->tanggal_selesai); ?>">
                                        <i class="icon_calendar"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Metode Kegiatan</label>
                                        <input class="form-control" type="name" name="metode_kegiatan" value="<?php echo e(old('metode_kegiatan') ?? $data->metode_kegiatan); ?>">
                                        <i class="icon_calendar"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>Kegiatan</label>
                                        <input class="form-control" type="name" name="kegiatan" value="<?php echo e(old('kegiatan') ?? $data->kegiatan); ?>">
                                        <i class="icon_calendar"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Rincian Kegiatan</label>
                                <textarea class="editor" name="rincian_kegiatan"><?php echo e(old('rincian_kegiatan') ?? $data->rincian_kegiatan); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Kriteria Peserta</label>
                                <textarea class="editor" name="kriteria_peserta"><?php echo e(old('kriteria_peserta') ?? $data->kriteria_peserta); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Informasi Kegiatan</label>
                                <textarea class="editor" name="informasi_tambahan"><?php echo e(old('informasi_tambahan') ?? $data->informasi_tambahan); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <p><button type="submit" class="btn btn-primary plus float-right">Update</button></p>
                </form>
            </div>
            <!-- /tables-->
        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/dashboard/program/edit.blade.php ENDPATH**/ ?>