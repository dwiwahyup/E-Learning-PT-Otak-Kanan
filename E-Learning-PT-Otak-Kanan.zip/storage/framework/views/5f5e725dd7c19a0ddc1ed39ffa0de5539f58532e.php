

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container-fluid">
        <a class="btn btn-link mb-2" href="<?php echo e(URL::previous()); ?>">
                <i class="fa fa-chevron-left" aria-hidden="true"></i> Back
        </a>

        <?php if($errors->any()): ?>
                    <div class="mb-5" role="alert">
                        <div class="alert alert-danger" role="alert">
                            <p>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eror): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($eror); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </p>
                        </div>
                    </div>
                <?php endif; ?>

        <!-- Example DataTables Card-->
        <div class="card mb-3">
            <div class="card-header">
                <i></i> Tambah Materi Baru
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('coursecategory.chapter.content.store', ['coursecategory' => $coursecategory->id, 'chapter' => $chapter->id])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="title" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Link Vidio</label>
                                <input type="text" name="vidio" class="form-control">
                                <small class="form-text text-danger">Please input link form youtube like : https://www.youtube.com/embed/tgbNymZ7vqY</small>
                            </div>
                            <div class="form-group">
                                <label>Thumbnile</label>
                                <input type="file" name="thumbnaile" class="form-control">
                                <small class="form-text mb-3 text-danger">Please input image in size 400X800</small>
                            </div>
                            <div class="form-group">
                                <label>Text</label>
                                <textarea class="editor" name="text"></textarea>
                            </div>
                        </div>
                    </div>
                        <p><button type="submit" class="btn btn-primary plus float-right">Save</button></p>
                    </form>
            </div>
            
            <!-- /tables-->
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/dashboard/content/create.blade.php ENDPATH**/ ?>