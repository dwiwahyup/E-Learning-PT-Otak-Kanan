
<?php $__env->startSection('content'); ?>


<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(('/dashboard')); ?>">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Course</li>
        </ol>

        <?php if($message = Session::get('success')): ?>
        <div class="mb-10">
            <div class="alert alert-success" role="alert">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-table"></i> Course Data
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <p><a href="/dashboard/coursecategory/create/" class="btn btn-secondary plus"> Add Course</a>
                        </p>
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Course Name</th>
                                    <th>Introduction</th>
                                    <th>Chapter</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Course Name</th>
                                    <th>Introduction</th>
                                    <th>Chapter</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->name); ?></td>
                                    <td>
                                        <?php echo Str::limit($data->introduction, 50); ?>

                                    </td>
                                    <td><?php echo e($data->chapters_count); ?> Chapter</td>
                                    <td>
                                        <?php if($data->image_url != null): ?>
                                        <img src="<?php echo e($data->image_url); ?>" alt="" width="200px" height="100px">
                                        <?php else: ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="inline-block">
                                            <a href="<?php echo e(route('coursecategory.chapter.index', $data->slug)); ?>"
                                                class="btn btn-success btn-md">Chapter</a>
                                            <a href="<?php echo e(route('coursecategory.edit', $data->slug)); ?>"
                                                class="btn btn-danger btn-md ml-1">Edit</a>
                                            <form action="<?php echo e(route('coursecategory.destroy', $data->id)); ?>"
                                                class="d-inline" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('delete')); ?>

                                                <button class="btn btn-danger ml-1">Delete</button>
                                            </form>
                                            <a href="student/<?php echo e($data->slug); ?>"
                                                class="btn btn-danger btn-md ml-1">Student</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
            </div>
            <!-- /tables-->
        </div>
        <!-- /container-fluid-->
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dokumen\Polije\Magang\PT Otak Kanan\E-Learning-PT-Otak-Kanan\resources\views/dashboard/coursecategory/index.blade.php ENDPATH**/ ?>